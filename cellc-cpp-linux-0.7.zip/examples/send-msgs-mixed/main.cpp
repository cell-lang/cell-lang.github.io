#include <vector>
#include <exception>
#include <string>
#include <fstream>
#include <cstdio>

#include "generated.h"


using std::vector;
using std::exception;
using std::string;
using std::ifstream;
using std::ofstream;
using std::getline;

using cell_lang::Logins;


int main(int argc, char **argv) {
  if (argc != 4) {
    puts("Usage: send-msgs <initial state> <message list> <final state>");
    return 1;
  }

  // Reading the message list, with one message per line
  // Do not split a single message over multiple lines
  vector<string> messages;
  ifstream file(argv[2]);
  string line; 
  while (getline(file, line))
    messages.push_back(line);

  // Creating the automaton
  Logins logins;

  // Loading the initial state
  ifstream input(argv[1]);
  logins.load(input);

  // Printing the initial state
  ofstream output_0("state-0.txt");
  logins.save(output_0);

  // Sending the messages and printing the results
  for (int i=0 ; i < messages.size() ; i++) {
    string msg = messages[i];
    // Skipping lines that are empty or commented out
    if (msg != "" && msg.substr(0, 2) != "//") {
      try {
        logins.execute(msg);
        fprintf(stderr, "Success: %s\n\n", msg.c_str());
      }
      catch (exception &e) {
        fprintf(stderr, "Failure: %s\n\n", msg.c_str());
      }
      // Printing the state after the update
      ofstream output("state-" + std::to_string(i + 1) + ".txt");
      logins.save(output);
    }
  }

  // Saving the final state to the indicated file
  ofstream output(argv[3]);
  logins.save(output);

  return 0;
}
